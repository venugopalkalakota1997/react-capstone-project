import React from 'react';
import { Link, Switch, Route } from 'react-router-dom';
import Login from './Login';
import Signup from './Signup';
import AddInvoice from './AddInvoice';
import Dashboard from './Dashboard';
import './style.css'
import { withRouter } from "react-router-dom"

class Navbar extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            username: localStorage.getItem("username"),
            type:localStorage.getItem("type")
        }
    }


    logout = (e) => {
        localStorage.removeItem("username")
        localStorage.removeItem("type")
        this.props.history.push('/')
    }

    render() {
        let username = localStorage.getItem("username")
      
        console.log(username);
        return (
            <div>

                <nav className="nav">

                    {username === null &&
                        <div className="custom-nav">
                            <Link to="/dashboard">Supplier Finance System</Link>
                            <Link className="buttonnav" to='/register'>SignUp</Link> &nbsp;
                            <Link className="buttonnav" to='/login'>Login</Link>&nbsp;&nbsp;
                        </div>
                    }
                    {username !== null &&
                        <div className="custom-nav">
                            <Link to="/dashboard">Supplier Finance System</Link>
                            <button type="button" className="buttonnav1" onClick={this.logout}> logout</button>&nbsp;&nbsp;
                            <Link className="buttonnav" disabled={true}>{username} </Link>&nbsp;
                        </div>
                    }

                </nav>

                <div>
                    <Switch>
                        <Route exact path='/' component={Login}></Route>
                        <Route path='/login' component={Login}></Route>
                        <Route path='/register' component={Signup}></Route>
                        <Route path='/add' component={AddInvoice}></Route>
                        <Route path='/dashboard' component={Dashboard}></Route>
                    </Switch>
                </div>
            </div>
        );
    }
}

export default withRouter(Navbar);