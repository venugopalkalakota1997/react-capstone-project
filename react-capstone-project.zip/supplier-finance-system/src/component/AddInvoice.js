import React from 'react'
import axios from "axios";

class AddInvoice extends React.Component {

    constructor(props) {
        super(props)
        this.state = {
            invoiceNumber: 0,
            invoiceDate: '',
            invoiceAmount: '',
            currency: '',
            supplierId: 0,
            clientId: 0,
            invoice: '',
            fromerr: false,
            invoiceNumberError: '',
            invoiceDateError: '',
            productdetailsError: '',
            invoiceAmountError: '',
            currencyError: '',
            supplierError: '',
            invoiceError: '',
            buttonStatus: true,
            addSuccess: false,
            response: '',
            addMessage: ''
        }
    }
    getInvoiceNumber = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceNumber: event.target.value })
        this.checkValidation(event)
    }
    getblurInvoiceNumber = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceNumber: event.target.value })
        this.checkValidation('invoiceNumber');
    }
    getInvoiceDate = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceDate: event.target.value })
        this.checkValidation(event)
    }
    getblurinvoiceDate = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceDate: event.target.value })
        this.checkValidation('invoiceDate');
    }
    getInvoiceAmount = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceAmount: event.target.value })
        this.checkValidation(event)
    }
    getblurInvoiceAmount = (event) => {
        console.log(event.target.value)
        this.setState({ invoiceAmount: event.target.value })
        this.checkValidation('invoiceAmount');
    }

    getcurrency = (event) => {
        console.log(event.target.value)
        this.setState({ currency: event.target.value })
        this.checkValidation(event)
    }
    getblurcurrency = (event) => {
        console.log(event.target.value)
        this.setState({ currency: event.target.value })
        this.checkValidation('currency');
    }

    getInvoice = (event) => {
        console.log(event.target.value)
        this.setState({ invoice: event.target.files[0] })
        this.checkValidation(event)
    }
    getblurInvoice = (event) => {
        console.log(event.target.value)
        this.setState({ invoice: event.target.files[0] })
        this.checkValidation('invoice');
    }
    getsupplierId = (event) => {
        console.log(event.target.value)
        this.setState({ supplierId: event.target.value })
        this.checkValidation(event)
    }
    getblursupplierId = (event) => {
        console.log(event.target.value)
        this.setState({ supplierId: event.target.value })
        this.checkValidation('supplierId');
    }

    checkValidation(event) {
        console.log(event)
        let invoiceNumberError = ''
        let invoiceDateError = ''
        let invoiceAmountError = ''
        let currencyError = ''
        let supplierError = ''
        let invoiceError = ''

        if (event === 'invoiceNumber' && this.state.invoiceNumber === '') {
            invoiceNumberError = 'Invoice Number is Mandatory'
        } else if (event === 'invoiceDate' && this.state.invoiceDate === '') {
            invoiceDateError = 'Invoice Date is Mandatory'
        } else if (event === 'invoiceAmount' && this.state.invoiceAmount === '') {
            invoiceAmountError = 'Invoice Date is Mandatory'
        } else if (event === 'currency' && this.state.currency === '') {
            currencyError = 'Currency is Mandatory'
        } else if (event === 'supplierId' && this.state.supplierId === '') {
            supplierError = 'SupplierId is Mandatory'
        } else if (event === 'invoice' && this.state.invoice === '') {
            invoiceError = 'Invoice is Mandatory'
        }
        if (invoiceNumberError || invoiceDateError || invoiceAmountError || currencyError || supplierError || invoiceError) {
            this.setState({
                invoiceNumberError: invoiceNumberError,
                invoiceDateError: invoiceDateError,
                invoiceAmountError: invoiceAmountError,
                currencyError: currencyError,
                supplierError: supplierError,
                invoiceError: invoiceError,
                buttonStatus: true
            })
            return false;
        }
        this.setState({
            invoiceNumberError: '',
            invoiceDateError: '',
            productdetailsError: '',
            invoiceAmountError: '',
            currencyError: '',
            supplierError: '',
            invoiceError: '',
            buttonStatus: false
        })
        return true;
    }

    addInvoice = () => {
        if (this.state.invoiceNumber === '' || this.state.invoiceDate === '' || this.state.invoiceAmount === '' || this.state.currency === '' || this.state.invoice === '' || this.state.supplierId === '') {
            this.setState({

                buttonStatus: false
            })

        } else {

            let formData = new FormData();
            formData.append('file', this.state.invoice)
            formData.append('invoiceNumber',this.state.invoiceNumber)
            formData.append('invoiceDate',this.state.invoiceDate)
            formData.append('invoiceAmount',this.state.invoiceAmount)
            formData.append('currency',this.state.currency)
            
            
            axios.post('http://localhost:83/invoice/save/' + localStorage.getItem("username") + '/' + this.state.supplierId + "/", formData,
                )
                .then(response => {
                    console.log(response);
                    this.setState({ addSuccess: true })
                    this.intializeState()
                    this.props.history.push('/dashboard')
                }, error => {
                    console.error(error);
                    this.setState({
                        response: error.status,
                        addMessage: error.response.data,
                        addSuccess: false
                    })
                })
        }
    }
    intializeState = () => {
        setTimeout(() => {
            this.setState({ addSuccess: false })
        }, 2000)
    }
    render() {
        return (
            <form className="form" >
                {!this.state.addSuccess &&
                    <div >
                        <h5 className="loginerror">{this.state.addMessage}</h5>
                    </div>
                }
                <h2 >Add invoice</h2>
                <br></br>
                <p>Invoice Number <span style={{ color: 'red' }}> *</span></p>
                <input className="input" type="number" id="invoiceNumber" onChange={this.getInvoiceNumber} onBlur={this.getblurInvoiceNumber}></input>
                <p className="error">{this.state.invoiceNumberError}</p>

                <p>Invoice Date <span style={{ color: 'red' }}> *</span></p>
                <input type="date" className="input" id="invoiceDate" onChange={this.getInvoiceDate} onBlur={this.getblurinvoiceDate}></input>
                <p className="error">{this.state.invoiceDateError}</p>

                <p>Invoice Amount <span style={{ color: 'red' }}> *</span></p>
                <input type="number" className="input" id="invoiceAmount" onChange={this.getInvoiceAmount} onBlur={this.getblurInvoiceAmount}></input>
                <p className="error">{this.state.invoiceAmountError}</p>

                <p>currency <span style={{ color: 'red' }}> *</span></p>
                <select id="currency" className="input" onChange={this.getcurrency} onBlur={this.getblurcurrency}>
                    <option id="currency">Select option</option>
                    <option id="currency">USD</option>
                    <option id="currency">GBP</option>
                    <option id="currency">EURO </option>
                </select><br></br>
                <p className="error">{this.state.currencyError}</p>
                <p>Supplier Id <span style={{ color: 'red' }}> *</span></p>
                <input type="number" className="input" id="supplierId" onChange={this.getsupplierId} onBlur={this.getblursupplierId}></input>
                <p className="error">{this.state.supplierError}</p>

                <p>Select Invoice <span style={{ color: 'red' }}> *</span></p>
                <input type="file" onChange={this.getInvoice} onBlur={this.getblurInvoice} ></input><br></br>
                <p className="error">{this.state.invoiceError}</p>
                <br></br>
                <button type="submit" className="button" onClick={this.addInvoice} disabled={this.state.buttonStatus}>Add</button>
            </form>

        );
    }
}

export default AddInvoice;