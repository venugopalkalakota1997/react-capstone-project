import React from 'react';
import './style.css';
import axios from "axios";

class Login extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            id: 0,
            username: '',
            password: '',
            logindetails: [],
            nameError: '',
            passwordError: '',
            type: '',
            typeError: '',
            buttonStatus: true,
            loginstatus: false,
            response: '',
            loginMessage:''
        }
    }
    componentWillMount() {
        // localStorage.removeItem("username", this.state.username)
    }

    getName = (event) => {
        console.log(event.target.value)
        this.setState({ username: event.target.value })
        this.checkValidation(event)
    }

    getPassword = (event) => {
        console.log(event.target.value)
        this.setState({ password: event.target.value })
        this.checkValidation(event)
    }
    gettype = (event) => {
        console.log(event.target.value)
        this.setState({ type: event.target.value })
        this.checkValidation(event)
    }
    getblurName = (event) => {

        this.setState({ username: event.target.value })
        this.checkValidation("username")
    }

    getblurPasswword = (event) => {

        console.log(event.target.value)
        this.setState({ password: event.target.value })
        this.checkValidation('password');
    }
    getblurType = (event) => {
        console.log(event.target.value)
        this.setState({ type: event.target.value })
        this.checkValidation('type');
    }

    checkValidation(event) {
        console.log(event)
        let nameerror = ''
        let passworderror = ''
        let typeError = ''
        if (event === 'username' && this.state.username === '') {
            console.log('set state for nameError');
            nameerror = 'Name is Required'
        }
        else if (event === 'password' && this.state.password === '') {
            console.log('set state for passwordError');
            passworderror = 'Password is Required'
        }

        else if (event === 'type' && this.state.type === '') {
            console.log('set state for passwordError');
            typeError = 'Type is Required'
        }
        //check for other conditions!
        if (nameerror || passworderror) {

            this.setState({
                nameError: nameerror,
                passwordError: passworderror,
                typeError: typeError,
                buttonStatus: true
            })

            return false
        }
        this.setState({
            nameError: '',
            passwordError: '',
            typeError: '',
            buttonStatus: false
        })
        return true

    }
    setlocalstorage() {
        localStorage.setItem("username", this.state.username)
        localStorage.setItem("type",this.state.type)
    }



    login = (event) => {

        if (this.state.type === 'Supplier') {
            axios.get('http://localhost:83/login/supplier/' + this.state.username + '/' + this.state.password)
                .then(response => {
                    console.log(response)
                    this.setState({
                        response: response.status,
                        loginMessage: response.data
                    })
                   
                        localStorage.setItem("username", this.state.username)
                        localStorage.setItem("type",this.state.type)
                        this.props.history.push('/dashboard')
                   
                }, error => {
                   
                    this.setState({
                        response: error.status,
                        loginMessage: error.response.data,
                        username: '',
                        password: '',
                        type:'',
                        loginstatus: true
                    })
                })
        } else if (this.state.type === 'Client') {
            axios.get('http://localhost:83/login/client/' + this.state.username + '/' + this.state.password)
                .then(response => {
                    console.log(response)
                    this.setState({
                        response: response.status,
                        loginMessage: response.data
                        
                    })
                    
                        localStorage.setItem("username", this.state.username)
                        localStorage.setItem("type",this.state.type)
                        this.props.history.push('/dashboard')
                   
                 
                }, error => {
                    this.setState({
                        response: error.status,
                        loginMessage: error.response.data,
                        username: '',
                        password: '',
                        type:'',
                        loginstatus: true
                    })
                })
        }
    }


    render() {
        return (
            <form className="form">
                {this.state.loginstatus &&
                    <div >
                        <h5 className="loginerror">{this.state.loginMessage}</h5>
                    </div>
                }
                <h3>login Component</h3>
                <p >Name </p>
                <input className="input" type='text' id="username" onChange={this.getName} onBlur={this.getblurName}></input>
                <p className="error">{this.state.nameError}</p>
                <p >Password </p>
                <input className="input" type='password' id="password" onChange={this.getPassword} onBlur={this.getblurPasswword}></input>
                <br></br>
                <p className="error">{this.state.passwordError}</p>
                <p >Type Of Login </p>
                <select id="type" className="input" onChange={this.gettype} value={this.state.type} onBlur={this.getblurType}>
                    <option id="type"></option>
                    <option id="type">Client</option>
                    <option id="type">Supplier </option>
                </select><br></br>
                <p className="error">{this.state.typeError}</p>
                <button type="submit" className="button" onClick={this.login} disabled={this.state.buttonStatus}>Login</button>
            </form>

        );
    }
}

export default Login;