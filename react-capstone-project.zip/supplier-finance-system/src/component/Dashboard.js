import React from 'react'
import axios from "axios";

class Dashboard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            invoices: [],
            totalInvoices: '',
            addInvoice: false,
            invoice:''
        }
    }


    componentWillMount() {

        this.getAllInvoices()

    }

    getAllInvoices = (event) => {
        if(localStorage.getItem('type') === 'Client' ){
            this.setState({
                addInvoice:true
            })
        }
        axios.get('http://localhost:83/invoice/' + localStorage.getItem('type') + '/' + localStorage.getItem('username') + '/')
            .then(response => {
                this.setState({
                    invoices: response.data,
                    totalInvoices: response.data.length,
                })
            }, error => {
                console.error(error);
            })
    }
    addInvoicebutton = (event)=>{
        this.props.history.push('/add')
    }
    getStatus=(e)=>{
        if(null !== e){
            return 'Invoice Attached'
        }

        return 'Invoice Not Attached'
    }
    getAllInvoicesFlag=()=>{
        if(this.state.invoices.length === 0)
        return true;
        else
         return false;
    }

    render() {
        return (
            <div>
                { this.state.addInvoice && 
                <button type="submit" className="addInvoice" onClick={this.addInvoicebutton}>Add Invoice</button>
                }
                {
                    !this.getAllInvoicesFlag() &&
                
                <table>

                    <tbody>
                        <tr>
                            
                            <th>Invoice number</th>
                            <th>Invoice Date</th>
                            <th>Invoice amount</th>
                            <th>Currency</th>
                            <th>Supplier code</th>
                            <th>Invoice Status</th>
                        </tr>

                        {this.state.invoices.map((val, key) => {
                          
                            return (
                                
                                <tr key={key}>
                                    <td>{val.invoiceNumber}</td>
                                    <td>{val.invoiceDate}</td>
                                    <td>{val.invoiceAmount}</td>
                                    <td>{val.currency}</td>
                                    <td>{val.supplier.id}</td>
                                    <td>{this.getStatus(val.invoice)}</td>
                                    
                                </tr>

                            )
                        })}
                    </tbody>
                </table>
    }
            </div>
        )
    }
}
export default Dashboard;