import React from 'react'
import './style.css';
import axios from "axios";

class Signup extends React.Component {


    constructor(props) {
        super(props)
        this.state = {
            username: '',
            address: '',
            email: '',
            password: '',
            confirmPassword: '',
            contactNumber: '',
            creditAccountNumber: '',
            creditInformation: '',
            loanAccountNumber: '',
            loanInformation: '',
            loginMessage: '',
            nameError: '',
            addressError: '',
            contactNumberError: '',
            passwordError: '',
            confirmPasswordError: '',
            emailError: '',
            creditAccountNumberError: '',
            creditInformationError: '',
            loanAccountNumberError: '',
            loanInformationError: '',
            buttonStatus: true,
            signSuccess: false,
            textflag: false
        }
    }

    getName = (event) => {
        console.log(event.target.value)
        this.setState({ username: event.target.value })
        this.checkValidation(event)
    }
    getAddress = (event) => {
        console.log(event.target.value)
        this.setState({ address: event.target.value })
        this.checkValidation(event)
    }

    getEmail = (event) => {
        console.log(event.target.value)
        this.setState({ email: event.target.value })
        this.checkValidation(event)
    }
    getCreditAccountNumber = (event) => {
        console.log(event.target.value)
        this.setState({ creditAccountNumber: event.target.value })
        this.checkValidation(event)
    }

    getCreditInformation = (event) => {
        console.log(event.target.value)
        this.setState({ creditInformation: event.target.value })
        this.checkValidation(event)
    }

    getLoanAccountNumber = (event) => {
        console.log(event.target.value)
        this.setState({ loanAccountNumber: event.target.value })
        this.checkValidation(event)
    }

    getLoanInformation = (event) => {
        console.log(event.target.value)
        this.setState({ loanInformation: event.target.value })
        this.checkValidation(event)
    }
    getconfirmPassword = (event) => {
        console.log(event.target.value)
        this.setState({ confirmPassword: event.target.value })
        this.checkValidation(event)
    }
    getPassword = (event) => {
        console.log(event.target.value)
        this.setState({ password: event.target.value })
        this.checkValidation(event)
    }
    getcontactNumber = (event) => {
        console.log(event.target.value)
        this.setState({ contactNumber: event.target.value })
        this.checkValidation(event)
    }



    getblurName = (event) => {
        this.setState({ username: event.target.value })
        this.checkValidation("username")
    }
    getblurAddress = (event) => {
        this.setState({ address: event.target.value })
        this.checkValidation("address")
    }

    getblurEmail = (event) => {
        console.log(event.target.value)
        this.setState({ email: event.target.value })
        this.checkValidation("email")
    }
    getblurCreditAccountNumber = (event) => {
        console.log(event.target.value)
        this.setState({ creditAccountNumber: event.target.value })
        this.checkValidation("creditAccountNumber")
    }

    getblurCreditInformation = (event) => {
        console.log(event.target.value)
        this.setState({ creditInformation: event.target.value })
        this.checkValidation("creditInformation")
    }

    getblurLoanAccountNumber = (event) => {
        console.log(event.target.value)
        this.setState({ loanAccountNumber: event.target.value })
        this.checkValidation("loanAccountNumber")
    }

    getblurLoanInformation = (event) => {
        console.log(event.target.value)
        this.setState({ loanInformation: event.target.value })
        this.checkValidation("loanInformation")
    }
    getblurPassword = (event) => {
        console.log(event.target.value)
        this.setState({ password: event.target.value })
        this.checkValidation('password');
    }
    getblurcontactNumber = (event) => {
        console.log(event.target.value)
        this.setState({ contactNumber: event.target.value })
        this.checkValidation('contactnumber');
    }
    getblurconfirmPassword = (event) => {
        console.log(event.target.value)
        this.setState({ confirmPassword: event.target.value })
        this.checkValidation('confirmPassword');
    }

    checkValidation(event) {

        let nameerror = ''
        let passworderror = ''
        let contactnumbererror = ''
        let confirmpassworderror = ''
        let addressError = ''
        let emailError = ''
        let creditAccountNumberError = ''
        let creditInformationError = ''
        let loanAccountNumberError = ''
        let loanInformationError = ''
        const regex = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
        if (event === 'username' && (this.state.username === '' || this.state.username.length <= 2 || this.state.username.length >= 30)) {

            nameerror = 'Name should be more 2 chacter and less than 30 chracter'
        }
        else if (event === 'password' && this.state.password === '') {

            passworderror = 'Password is Required'
        }
        else if (event === 'confirmPassword' && (this.state.confirmPassword === '' || this.state.password !== this.state.confirmPassword)) {

            confirmpassworderror = 'Password mismatch'
        }
        else if (event === 'contactnumber' && (this.state.contactNumber === '' || this.state.contactNumber.length !== 10)) {

            contactnumbererror = 'Contact number is Required or should be 10digit'
        }
        else if (event === 'address' && this.state.address === '') {
            addressError = 'Address is required'
        }
        else if (event === 'email' && (this.state.email === '' || regex.test(this.state.email) === false)) {
            emailError = 'Email is not correct format'
        }
        else if (event === 'creditAccountNumber' && this.state.creditAccountNumber === '' && this.state.textflag) {
            creditAccountNumberError = 'credit Account Number is required'
        }
        else if (event === 'creditInformation' && this.state.creditInformation === '' && this.state.textflag) {
            creditInformationError = 'Credit Information is required'
        } else if (event === 'loanAccountNumber' && this.state.loanAccountNumber === '' && !this.state.textflag) {
            loanAccountNumberError = 'Loan Account Number is Required'
        } else if (event === 'loanInformation' && this.state.loanInformation === '' && !this.state.textflag) {
            loanInformationError = 'Loan Information is Required'
        }
        //check for other conditions!
        if (nameerror || passworderror || confirmpassworderror || contactnumbererror || emailError || creditAccountNumberError || creditInformationError || addressError || loanAccountNumberError || loanInformationError) {

            this.setState({
                nameError: nameerror,
                passwordError: passworderror,
                contactNumberError: contactnumbererror,
                confirmPasswordError: confirmpassworderror,
                addressError: addressError,
                emailError: emailError,
                creditInformationError: creditInformationError,
                creditAccountNumberError: creditAccountNumberError,
                loanInformationError: loanInformationError,
                loanAccountNumberError: loanAccountNumberError,
                buttonStatus: true
            })

            return false
        }
        this.setState({
            nameError: '',
            addressError: '',
            contactNumberError: '',
            passwordError: '',
            confirmPasswordError: '',
            emailError: '',
            creditAccountNumberError: '',
            creditInformationError: '',
            loanInformationError: '',
            loanAccountNumberError: '',
            buttonStatus: false
        })
        return true

    }



    intializeState = () => {
        setTimeout(() => {
            this.setState({ signSuccess: false })
        }, 2000)
    }

    signupClient = () => {
        if (this.state.username === '' || this.state.password === '' || this.state.contactNumber === '' || this.state.confirmPassword === '' || this.state.address === '' || this.state.email === '') {
            this.setState({
                buttonStatus: false
            })
        }
        else {
            let client = {
                "name": this.state.username,
                "address": this.state.address,
                "email": this.state.email,
                "mobileNumber": this.state.contactNumber,
                "creditAccountNumber": this.state.creditAccountNumber,
                "creditInformation": this.state.creditInformation,
                "password": this.state.password,

            }
            axios.post('http://localhost:83/registration/client/', client)
                .then(response => {
                    console.log(response);
                    this.setState({ signSuccess: true })
                    this.intializeState()
                    this.props.history.push('/login')
                }, error => {
                    console.error(error);
                    this.setState({
                        response: error.status,
                        loginMessage: error.response.data,
                        signSuccess: false
                    })
                    console.log(this.state.signSuccess)
                })
        }
    }
    signupSupplier = () => {
        if (this.state.username === '' || this.state.password === '' || this.state.contactNumber === '' || this.state.confirmPassword === '' || this.state.address === '' || this.state.email === '') {
            this.setState({
                buttonStatus: false
            })
        }
        else {
            let supplier = {
                "name": this.state.username,
                "address": this.state.address,
                "email": this.state.email,
                "mobileNumber": this.state.contactNumber,
                "loanAccountNumber": this.state.loanAccountNumber,
                "loanInformation": this.state.loanInformation,
                "password": this.state.password,

            }
            axios.post('http://localhost:83/registration/supplier/', supplier)
                .then(response => {
                    console.log(response);
                    this.setState({ signSuccess: true })
                    this.intializeState()
                    this.props.history.push('/login')
                }, error => {
                    console.error(error);
                    this.setState({
                        response: error.status,
                        loginMessage: error.response.data,
                        signSuccess: false
                    })
                    console.log(this.state.signSuccess)
                })
        }
    }
    ToggleButton() {
        this.setState(
            { textflag: !this.state.textflag }
        );
    }

    render() {
        return (
            <div>
                <div className="form">
                {!this.state.textflag && <button className="buttonnavReg" onClick={() => this.ToggleButton()} >Client Registration</button>}
                {this.state.textflag &&    <button className="buttonnavReg" onClick={() => this.ToggleButton()}>Supplier Registration</button>}
                </div>
                <div>
                    {this.state.textflag &&
                        <form className="form">
                            {!this.state.signSuccess &&
                                <div >
                                    <h5 className="loginerror">{this.state.loginMessage}</h5>
                                </div>
                            }
                            <h2> Client Signup </h2>
                            <p >Name <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="username" onChange={this.getName} onBlur={this.getblurName}></input>
                            <p className="error">{this.state.nameError}</p>
                            <p >Address <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="address" onChange={this.getAddress} onBlur={this.getblurAddress}></input>
                            <p className="error">{this.state.addressError}</p>
                            <p >Email <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="email" onChange={this.getEmail} onBlur={this.getblurEmail}></input>
                            <p className="error">{this.state.emailError}</p>
                            <p >Contact Number <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="contactNumber" onChange={this.getcontactNumber} onBlur={this.getblurcontactNumber}></input>
                            <p className="error">{this.state.contactNumberError}</p>
                            <p >Credit Account Number <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="creditAccountNumber" onChange={this.getCreditAccountNumber} onBlur={this.getblurCreditAccountNumber}></input>
                            <p className="error">{this.state.creditAccountNumberError}</p>
                            <p >Credit Information <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="creditInformation" onChange={this.getCreditInformation} onBlur={this.getblurCreditInformation}></input>
                            <p className="error">{this.state.creditInformationError}</p>
                            <p>Password<span style={{ color: 'red' }}> *</span> </p>
                            <input className="input" type='password' id="password" onChange={this.getPassword} onBlur={this.getblurPassword}></input>
                            <p className="error">{this.state.passwordError}</p>
                            <p>Confirm Password <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='password' id="confirmPassword" onChange={this.getconfirmPassword} onBlur={this.getblurconfirmPassword}></input>
                            <br></br>
                            <p className="error">{this.state.confirmPasswordError}</p>
                            <br></br>
                            <button type="submit" className="button" onClick={this.signupClient} disabled={this.state.buttonStatus}>Signup</button>
                        </form>
                    }
                </div>
                <div>
                    {!this.state.textflag &&
                        <form className="form">
                            {!this.state.signSuccess &&
                                <div >
                                    <h5 className="loginerror">{this.state.loginMessage}</h5>
                                </div>
                            }
                            <h2>Supplier Signup</h2>
                            <p >Name <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="username" onChange={this.getName} onBlur={this.getblurName}></input>
                            <p className="error">{this.state.nameError}</p>
                            <p >Address <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="address" onChange={this.getAddress} onBlur={this.getblurAddress}></input>
                            <p className="error">{this.state.addressError}</p>
                            <p >Email <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="email" onChange={this.getEmail} onBlur={this.getblurEmail}></input>
                            <p className="error">{this.state.emailError}</p>
                            <p >Contact Number <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="contactNumber" onChange={this.getcontactNumber} onBlur={this.getblurcontactNumber}></input>
                            <p className="error">{this.state.contactNumberError}</p>
                            <p >Credit Account Number <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="loanAccountNumber" onChange={this.getLoanAccountNumber} onBlur={this.getblurLoanAccountNumber}></input>
                            <p className="error">{this.state.loanAccountNumberError}</p>
                            <p >Credit Information <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='text' id="loanInformation" onChange={this.getLoanInformation} onBlur={this.getblurLoanInformation}></input>
                            <p className="error">{this.state.loanInformationError}</p>
                            <p>Password<span style={{ color: 'red' }}> *</span> </p>
                            <input className="input" type='password' id="password" onChange={this.getPassword} onBlur={this.getblurPassword}></input>
                            <p className="error">{this.state.passwordError}</p>
                            <p>Confirm Password <span style={{ color: 'red' }}> *</span></p>
                            <input className="input" type='password' id="confirmPassword" onChange={this.getconfirmPassword} onBlur={this.getblurconfirmPassword}></input>
                            <br></br>
                            <p className="error">{this.state.confirmPasswordError}</p>
                            <br></br>
                            <button type="submit" className="button" onClick={this.signupSupplier} disabled={this.state.buttonStatus}>Signup</button>
                        </form>
                    }
                </div>
            </div>
        );
    }
}

export default Signup;