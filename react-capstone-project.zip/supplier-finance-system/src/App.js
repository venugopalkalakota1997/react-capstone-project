import './App.css';
import Navbar from './component/Navbar';

function App() {
  return (
    
    <div>
      <Navbar></Navbar>
    </div>
  );
}

export default App;
